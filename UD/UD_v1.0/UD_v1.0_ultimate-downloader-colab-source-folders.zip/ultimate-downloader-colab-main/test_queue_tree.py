"""Run the queue table widget (list + tree views) in a real DOM.

Needs Node.js and jsdom (`npm install jsdom` next to this file, or point UD_NODE_MODULES at a
node_modules folder that has it); the checks are skipped otherwise.
"""
import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from test_queue_additions_torbox import load_definitions

HERE = Path(__file__).resolve().parent
NODE = shutil.which('node')


def node_env():
    env = dict(os.environ)
    paths = [str(HERE / 'node_modules')]
    if env.get('UD_NODE_MODULES'):
        paths.insert(0, env['UD_NODE_MODULES'])
    if env.get('NODE_PATH'):
        paths.append(env['NODE_PATH'])
    env['NODE_PATH'] = os.pathsep.join(paths)
    return env


def has_jsdom():
    if not NODE:
        return False
    probe = subprocess.run([NODE, '-e', "require('jsdom')"], capture_output=True, env=node_env())
    return probe.returncode == 0


@unittest.skipUnless(has_jsdom(), 'Node.js with jsdom is needed for the queue widget DOM checks')
class QueueWidgetDomTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        namespace = {}
        load_definitions(namespace, '_QUEUE_TABLE_ESM')
        with tempfile.TemporaryDirectory() as folder:
            widget = Path(folder) / 'queue_table.mjs'
            widget.write_text(namespace['_QUEUE_TABLE_ESM'], encoding='utf-8')
            run = subprocess.run([NODE, str(HERE / 'queue_table_scenarios.cjs'), str(widget)],
                                 capture_output=True, text=True, env=node_env(), timeout=120)
        if run.returncode:
            raise AssertionError(run.stderr[-2000:])
        cls.results = json.loads(run.stdout)

    def test_scenarios_ran(self):
        self.assertGreaterEqual(len(self.results), 15)

    def test_every_scenario_passes(self):
        for name, error in self.results.items():
            with self.subTest(scenario=name):
                self.assertIsNone(error, error)


if __name__ == '__main__':
    unittest.main()
