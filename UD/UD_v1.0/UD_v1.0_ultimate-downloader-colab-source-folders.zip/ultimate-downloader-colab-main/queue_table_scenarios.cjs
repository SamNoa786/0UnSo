// Drives the queue table widget in jsdom. usage: node scenarios.cjs <widget.mjs>
const assert = require('node:assert/strict');
const {pathToFileURL} = require('node:url');
const {JSDOM} = require('jsdom');

const dom = new JSDOM('<!doctype html><html><body></body></html>', {pretendToBeVisual: true});
const win = dom.window;
Object.assign(globalThis, {window: win, document: win.document, getComputedStyle: win.getComputedStyle.bind(win),
                           AbortController: win.AbortController});

const MB = 1024 ** 2;
const mk = (id, number, name, folder, bytes) => ({id, number, name, source: 'TorBox', size: '', destination: '—',
                                                   overrides: '—', folder, bytes});
const ROWS = () => [
  mk('a', '1', 'Episode 01.mkv', 'My Show/Season 1', 10 * MB),
  mk('b', '2', 'Episode 02.mkv', 'My Show/Season 1', 20 * MB),
  mk('c', '3', 'Episode 01.mkv', 'My Show/Season 2', 30 * MB),
  mk('d', '4', 'Making Of.mkv', 'My Show/Extras', 5 * MB),
  mk('e', '5', 'loose.mkv', '', 1 * MB),
];

function makeModel(state) {
  const handlers = {};
  return {
    state,
    get: key => state[key],
    set(key, value) { state[key] = value; (handlers['change:' + key] || []).slice().forEach(fn => fn()); },
    save_changes() {},
    on(event, fn) { (handlers[event] = handlers[event] || []).push(fn); },
    off(event, fn) { handlers[event] = (handlers[event] || []).filter(f => f !== fn); },
  };
}

let widget;
function mount(state) {
  document.body.replaceChildren();
  const model = makeModel({rows: ROWS(), selected_ids: [], column_widths: [72, 330, 110, 90, 480, 180],
                           view_mode: 'list', ...state});
  const el = document.createElement('div'); document.body.append(el);
  widget.render({model, el});
  const q = sel => [...el.querySelectorAll(sel)];
  const ui = {
    model, el, q,
    body: el.querySelector('tbody'),
    visible: () => q('tbody tr[data-id], tbody tr[data-folder]').map(tr =>
      tr.dataset.folder !== undefined ? 'F:' + tr.dataset.folder : tr.dataset.id),
    folder: path => q('tr[data-folder]').find(tr => tr.dataset.folder === path),
    file: id => q('tr[data-id]').find(tr => tr.dataset.id === id),
    button: label => q('.ud-toolbar button').find(b => b.textContent.includes(label)),
    selectAll: () => el.querySelector('thead input[type=checkbox]'),
    selected: () => model.state.selected_ids.slice(),
    click: (node, init = {}) => node.dispatchEvent(new win.MouseEvent('click', {bubbles: true, cancelable: true, ...init})),
    key: (node, key, init = {}) => node.dispatchEvent(new win.KeyboardEvent('keydown', {key, bubbles: true, cancelable: true, ...init})),
    cbox: tr => tr.querySelector('input[type=checkbox]'),
  };
  return ui;
}

const TREE_ORDER = ['F:My Show', 'F:My Show/Season 1', 'a', 'b', 'F:My Show/Season 2', 'c',
                    'F:My Show/Extras', 'd', 'e'];
const scenarios = {
  list_view_is_unchanged() {
    const ui = mount({});
    assert.deepEqual(ui.visible(), ['a', 'b', 'c', 'd', 'e']);
    assert.equal(ui.q('tr.ud-folder').length, 0);
    assert.equal(ui.button('Expand').hidden, true);
    assert.equal(ui.button('List').getAttribute('aria-pressed'), 'true');
    ui.click(ui.file('b'));
    assert.deepEqual(ui.selected(), ['b']);
    ui.click(ui.file('d'), {shiftKey: true});
    assert.deepEqual(ui.selected(), ['b', 'c', 'd']);
  },
  legacy_selection_semantics_are_unchanged() {
    // Ported from the original slice-based harness: same clicks, ranges and keys, now through real DOM events.
    const rows = ['a', 'b', 'c', 'd', 'e'].map(id => mk(id, id, id, '', 0));
    let ui = mount({rows, selected_ids: ['e']});
    const sel = (...ids) => assert.deepEqual(ui.selected(), ids);
    ui.click(ui.file('a')); sel('a', 'e');
    ui.click(ui.file('c')); sel('a', 'c', 'e');
    ui.click(ui.file('a')); sel('c', 'e');
    ui.click(ui.file('b'), {shiftKey: true}); sel('a', 'b', 'c', 'e');
    ui.click(ui.file('d'), {ctrlKey: true}); sel('a', 'b', 'c', 'd', 'e');
    ui.click(ui.file('d'), {metaKey: true}); sel('a', 'b', 'c', 'e');
    ui.click(ui.body); sel('a', 'b', 'c', 'e');                       // a click outside any row changes nothing
    ui.key(ui.file('c'), 'ArrowDown'); sel('a', 'b', 'c', 'e');
    assert.equal(document.activeElement, ui.file('d'));
    ui.key(ui.file('d'), ' '); sel('a', 'b', 'c', 'd', 'e');
    ui.key(ui.file('d'), ' '); sel('a', 'b', 'c', 'e');
    ui.key(ui.file('d'), 'Home'); sel('a', 'b', 'c', 'e');
    assert.equal(document.activeElement, ui.file('a'));
    ui.key(ui.file('a'), 'End', {shiftKey: true}); sel('a', 'b', 'c', 'd', 'e');
    ui.selectAll().checked = false; ui.selectAll().dispatchEvent(new win.Event('change')); sel();
    ui = mount({rows, selected_ids: []});                              // fresh widget: no anchor yet
    ui.key(ui.file('b'), 'ArrowDown', {shiftKey: true}); sel('b', 'c');
    ui.key(ui.file('c'), 'a', {ctrlKey: true}); sel('a', 'b', 'c', 'd', 'e');
    ui.selectAll().checked = false; ui.selectAll().dispatchEvent(new win.Event('change')); sel();
    ui.selectAll().checked = true; ui.selectAll().dispatchEvent(new win.Event('change')); sel('a', 'b', 'c', 'd', 'e');
    ui.model.state.selected_ids = ['b', 'e'];
    ui.model.set('rows', rows.filter(row => row.id !== 'b'));          // b left the queue
    ui.click(ui.file('a')); sel('a', 'e');                             // stale ids are dropped on the next commit
  },
  tree_groups_files_by_folder() {
    const ui = mount({view_mode: 'tree'});
    assert.deepEqual(ui.visible(), TREE_ORDER);
    assert.match(ui.folder('My Show').textContent, /My Show \(4\)/);
    assert.match(ui.folder('My Show').textContent, /65\.0 MB/);
    assert.match(ui.folder('My Show/Season 1').textContent, /30\.0 MB/);
    const indent = tr => parseInt(tr.querySelectorAll('.ud-cell')[1].style.paddingLeft || '0', 10);
    assert.equal(indent(ui.folder('My Show')), 0);
    assert.equal(indent(ui.folder('My Show/Season 1')), 16);
    assert.ok(indent(ui.file('a')) > indent(ui.folder('My Show/Season 1')));
    assert.equal(ui.button('Expand').hidden, false);
    assert.equal(ui.button('Tree').getAttribute('aria-pressed'), 'true');
  },
  rows_without_folders_render_flat_in_tree_view() {
    const rows = ROWS().map(({folder, ...row}) => row);
    const ui = mount({view_mode: 'tree', rows});
    assert.deepEqual(ui.visible(), ['a', 'b', 'c', 'd', 'e']);
  },
  folder_checkbox_selects_and_clears_everything_inside() {
    const ui = mount({view_mode: 'tree'});
    ui.cbox(ui.folder('My Show/Season 1')).click();
    assert.deepEqual(ui.selected(), ['a', 'b']);
    assert.equal(ui.cbox(ui.folder('My Show/Season 1')).checked, true);
    assert.equal(ui.cbox(ui.folder('My Show')).indeterminate, true);
    assert.equal(ui.cbox(ui.folder('My Show/Season 2')).checked, false);
    assert.equal(ui.selectAll().indeterminate, true);
    ui.cbox(ui.folder('My Show/Season 1')).click();
    assert.deepEqual(ui.selected(), []);
    ui.cbox(ui.folder('My Show')).click();
    assert.deepEqual(ui.selected(), ['a', 'b', 'c', 'd']);
    assert.equal(ui.cbox(ui.folder('My Show')).checked, true);
    assert.equal(ui.cbox(ui.folder('My Show')).indeterminate, false);
  },
  a_partly_selected_folder_selects_the_rest_on_click() {
    const ui = mount({view_mode: 'tree'});
    ui.click(ui.file('a'));
    assert.equal(ui.cbox(ui.folder('My Show/Season 1')).indeterminate, true);
    ui.cbox(ui.folder('My Show/Season 1')).click();
    assert.deepEqual(ui.selected(), ['a', 'b']);
  },
  clicking_a_folder_row_opens_and_closes_it_without_touching_selection() {
    const ui = mount({view_mode: 'tree'});
    ui.cbox(ui.folder('My Show/Season 1')).click();
    ui.click(ui.folder('My Show/Season 1').querySelectorAll('.ud-cell')[1]);
    assert.deepEqual(ui.visible(), ['F:My Show', 'F:My Show/Season 1', 'F:My Show/Season 2', 'c',
                                    'F:My Show/Extras', 'd', 'e']);
    assert.equal(ui.folder('My Show/Season 1').getAttribute('aria-expanded'), 'false');
    assert.deepEqual(ui.selected(), ['a', 'b']);          // hidden files stay selected
    assert.equal(ui.cbox(ui.folder('My Show/Season 1')).checked, true);
    ui.click(ui.folder('My Show/Season 1'));
    assert.deepEqual(ui.visible(), TREE_ORDER);
  },
  header_checkbox_covers_files_hidden_in_collapsed_folders() {
    const ui = mount({view_mode: 'tree'});
    ui.click(ui.button('Collapse'));
    assert.deepEqual(ui.visible(), ['F:My Show', 'e']);
    ui.selectAll().click();
    assert.deepEqual(ui.selected(), ['a', 'b', 'c', 'd', 'e']);
    assert.equal(ui.selectAll().checked, true);
    assert.equal(ui.cbox(ui.folder('My Show')).checked, true);
    ui.selectAll().click();
    assert.deepEqual(ui.selected(), []);
  },
  expand_all_and_collapse_all() {
    const ui = mount({view_mode: 'tree'});
    ui.click(ui.button('Collapse'));
    assert.deepEqual(ui.visible(), ['F:My Show', 'e']);
    ui.click(ui.folder('My Show'));                       // open only the top folder
    assert.deepEqual(ui.visible(), ['F:My Show', 'F:My Show/Season 1', 'F:My Show/Season 2',
                                    'F:My Show/Extras', 'e']);
    ui.click(ui.button('Expand'));
    assert.deepEqual(ui.visible(), TREE_ORDER);
  },
  toggle_buttons_switch_views_and_keep_state() {
    const ui = mount({});
    ui.click(ui.button('Tree'));
    assert.equal(ui.model.state.view_mode, 'tree');
    assert.deepEqual(ui.visible(), TREE_ORDER);
    ui.click(ui.file('c'));
    ui.click(ui.button('List'));
    assert.equal(ui.model.state.view_mode, 'list');
    assert.deepEqual(ui.visible(), ['a', 'b', 'c', 'd', 'e']);
    assert.deepEqual(ui.selected(), ['c']);
    assert.equal(ui.button('Collapse').hidden, true);
  },
  shift_click_ranges_follow_the_visible_order() {
    const ui = mount({view_mode: 'tree'});
    ui.click(ui.folder('My Show/Season 2'));              // hides file c
    ui.click(ui.file('a'));
    ui.click(ui.file('d'), {shiftKey: true});
    assert.deepEqual(ui.selected(), ['a', 'b', 'd']);
  },
  keyboard_navigation_in_the_tree() {
    const ui = mount({view_mode: 'tree'});
    const season1 = ui.folder('My Show/Season 1');
    season1.focus();
    ui.key(season1, 'ArrowLeft');
    assert.equal(ui.folder('My Show/Season 1').getAttribute('aria-expanded'), 'false');
    assert.equal(document.activeElement, ui.folder('My Show/Season 1'));
    ui.key(ui.folder('My Show/Season 1'), 'ArrowRight');
    assert.equal(ui.folder('My Show/Season 1').getAttribute('aria-expanded'), 'true');
    ui.key(ui.folder('My Show/Season 1'), ' ');
    assert.deepEqual(ui.selected(), ['a', 'b']);
    ui.key(ui.folder('My Show/Season 1'), 'ArrowDown');
    assert.equal(document.activeElement, ui.file('a'));
    ui.key(ui.file('a'), 'ArrowDown');
    assert.equal(document.activeElement, ui.file('b'));
    ui.key(ui.file('b'), 'Home');
    assert.equal(document.activeElement, ui.folder('My Show'));
    ui.key(ui.folder('My Show'), 'End');
    assert.equal(document.activeElement, ui.file('e'));
    ui.key(ui.file('e'), 'a', {ctrlKey: true});
    assert.deepEqual(ui.selected(), ['a', 'b', 'c', 'd', 'e']);
  },
  selection_pushed_from_python_updates_folder_boxes() {
    const ui = mount({view_mode: 'tree'});
    ui.model.set('selected_ids', ['a', 'b', 'c', 'd', 'e']);
    ['My Show', 'My Show/Season 1', 'My Show/Season 2', 'My Show/Extras'].forEach(path =>
      assert.equal(ui.cbox(ui.folder(path)).checked, true, path));
    ui.model.set('selected_ids', ['c']);
    assert.equal(ui.cbox(ui.folder('My Show/Season 2')).checked, true);
    assert.equal(ui.cbox(ui.folder('My Show/Season 1')).checked, false);
    assert.equal(ui.cbox(ui.folder('My Show')).indeterminate, true);
  },
  collapsed_folders_survive_a_queue_refresh() {
    const ui = mount({view_mode: 'tree'});
    ui.click(ui.folder('My Show/Season 1'));
    const rows = ROWS().filter(row => row.id !== 'd');       // a file was removed from the queue
    ui.model.set('rows', rows);
    assert.deepEqual(ui.visible(), ['F:My Show', 'F:My Show/Season 1', 'F:My Show/Season 2', 'c', 'e']);
  },
  empty_queue_message() {
    ['list', 'tree'].forEach(mode => {
      const ui = mount({view_mode: mode, rows: []});
      assert.match(ui.body.textContent, /No files in the queue/);
    });
  },
};

(async () => {
  widget = (await import(pathToFileURL(process.argv[2]).href)).default;
  const results = {};
  for (const [name, run] of Object.entries(scenarios)) {
    try { run(); results[name] = null; }
    catch (error) { results[name] = String(error && error.stack || error).split('\n').slice(0, 4).join('\n'); }
  }
  console.log(JSON.stringify(results));
})();
