"""Exercise the real table model against the existing queue action regressions.

Run with anywidget installed to include the widget integration checks.
"""
import importlib.util
import unittest

import test_queue_editing as edit_cases
import test_queue_additions_torbox as add_cases


HAS_WIDGETS = importlib.util.find_spec('anywidget') is not None


# The click/range/keyboard checks that used to live here sliced the widget source and ran it against a
# hand-made stub. They now run against the real widget in a DOM: see test_queue_tree.py.


def make_table():
    import ipywidgets as widgets
    namespace = dict(widgets=widgets, drive=None)
    add_cases.load_definitions(namespace, '_QUEUE_TABLE_CSS', '_QUEUE_TABLE_ESM', '_create_queue_widget')
    table = namespace['_create_queue_widget']()
    assert hasattr(table, 'set_rows'), 'Expected the table, not the fallback list'
    return table


@unittest.skipUnless(HAS_WIDGETS, 'Install anywidget to test the real queue widget')
class TableEditingTests(edit_cases.QueueEditingTests):
    def setUp(self):
        super().setUp()
        self.ns['queue_list'] = make_table()
        self.addCleanup(self.ns['queue_list'].close)
        self.ns['update_queue_display'](preserve_selection=False)
        self.select(1, 2, 3)

    def test_full_filename_columns_and_sizes_are_not_truncated(self):
        filename = 'A Very Long Show Name ' * 8 + 'S02E01.mkv'
        self.rows[1].filename = filename + ' (123.4 MB)'
        self.ns['update_queue_display']()
        row = self.ns['queue_list'].rows[1]
        self.assertEqual(row['name'], filename)
        self.assertEqual(row['size'], '123.4 MB')
        self.assertEqual(row['source'], 'Direct')
        self.assertTrue(row['destination'])

    def test_rows_carry_the_folder_and_byte_size_the_tree_view_groups_on(self):
        self.rows[1].filename = 'Episode 01.mkv (123.4 MB)'
        self.rows[1].relative_path, self.rows[1].torrent_name = 'Season 1', 'My Show'
        self.rows[2].filename = 'Loose.mkv (2.0 GB)'
        self.rows[3].filename = 'No size.mkv'
        self.ns['update_queue_display']()
        rows = self.ns['queue_list'].rows
        self.assertEqual((rows[1]['folder'], rows[1]['bytes']), ('My Show/Season 1', int(123.4 * 1024 ** 2)))
        self.assertEqual((rows[2]['folder'], rows[2]['bytes']), ('', 2 * 1024 ** 3))
        self.assertEqual((rows[3]['folder'], rows[3]['bytes']), ('', 0))

    def test_widths_and_selected_task_ids_survive_sort_edit_and_removal(self):
        table = self.ns['queue_list']
        widths = [80, 650, 120, 95, 900, 250]
        table.column_widths = widths
        selected_ids = list(table.selected_ids)
        self.ns['queue_sort_alpha']()
        self.assertCountEqual(table.selected_ids, selected_ids)
        self.ns['queue_name_input'].value = 'Edited Show'
        self.ns['apply_queue_changes']()
        self.assertCountEqual(table.selected_ids, selected_ids)
        self.assertEqual(table.column_widths, widths)
        self.ns['queue_remove_selected']()
        self.assertEqual(table.selected_ids, [])
        self.assertEqual(table.column_widths, widths)

    def test_browser_selection_uses_ids_and_ignores_removed_files(self):
        table = self.ns['queue_list']
        table.selected_ids = [self.rows[4].id, 'removed-task-id']
        self.assertEqual(self.ns['_selected_queue_indices'](), [4])
        table.options = []
        self.assertEqual((table.rows, table.selected_ids, table.value), ([], [], ()))


@unittest.skipUnless(HAS_WIDGETS, 'Install anywidget to test the real queue widget')
class TableAppendTests(add_cases.AppendQueueTests):
    def setUp(self):
        super().setUp()
        self.ns['queue_list'] = make_table()
        self.addCleanup(self.ns['queue_list'].close)
        self.ns['update_queue_display'](preserve_selection=False)
        self.ns['queue_list'].value = (self.ns['queue_list'].options[0],)

    def test_appending_keeps_resized_columns(self):
        widths = [90, 600, 130, 100, 800, 300]
        self.ns['queue_list'].column_widths = widths
        self.add([self.task('New File.mkv')])
        self.assertEqual(self.ns['queue_list'].column_widths, widths)
        self.assertEqual(self.ns['_selected_queue_indices'](), [0, 2])


if __name__ == '__main__':
    unittest.main()
